EECS 4422 assignment 1
Written By ariel feygin student number 214527790
credit to computerphile on youtube for the algorithm for canny edge detection.
mytiltimage2 is the non horizontally restricted algorithm for q1 partf